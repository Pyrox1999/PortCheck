This portscanner searches in an ip-adress all ports from 1 to 1024 in step 10. If you want a specific range, you must
take my python-script and Change it there. It is absolute legal to code such a scanner and use it on my own
Apache Server on 127.0.0.1 like I did. But it is forbidden to use it on Websites where you have no permission! 

Music by G_P